-- phpMyAdmin SQL Dump
-- version 5.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Table structure for table `custom_fields`
--

CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `destinations`
--

CREATE TABLE `destinations` (
  `destination_id` int(11) NOT NULL,
  `model_type` varchar(255) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `location_name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `driver_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `driver_license_number` varchar(255) DEFAULT NULL,
  `vehicle_plate_number` varchar(20) DEFAULT NULL,
  `generated_password` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `help_messages`
--

CREATE TABLE `help_messages` (
  `message_id` int(11) NOT NULL,
  `subject` varchar(244) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `user_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `help_message_comments`
--

CREATE TABLE `help_message_comments` (
  `comment_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `user_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `receiver_type` varchar(255) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` int(11) NOT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `body` varchar(191) DEFAULT NULL,
  `body_text` varchar(255) NOT NULL,
  `status` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `notifications_events`
--

CREATE TABLE `notifications_events` (
  `id` int(11) NOT NULL,
  `title` varchar(191) NOT NULL,
  `action` varchar(191) NOT NULL,
  `model` varchar(191) NOT NULL,
  `receiver_model` varchar(255) NOT NULL,
  `action_field` varchar(255) DEFAULT NULL,
  `action_value` varchar(255) DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `body` text,
  `body_text` varchar(255) DEFAULT NULL,
  `status` varchar(191) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notifications_events`
--

INSERT INTO `notifications_events` (`id`, `title`, `action`, `model`, `receiver_model`, `action_field`, `action_value`, `subject`, `body`, `body_text`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'New Driver created', 'create', 'Medians\\Drivers\\Domain\\Driver', 'Medians\\Drivers\\Domain\\Driver', '', '', 'Your account has been created ', '<p>Welcome {{model.first_name}}</p>\r\n<p>You have new account with name </p> <b>{{model.name}}</b>\r\n<p></p>\r\n\r\n<p>Use your email and this password to login \r\n</p>\r\n<b>{{model.generated_password}} </b>\r\n<br />', 'Welcome {{model.first_name}}\r\n\r\nYou have new account with name {{model.name}}\r\n\r\nUse your email and this password to login \r\n\r\n{{model.generated_password}} ', 'on', NULL, '2023-10-30 15:16:34', '2023-11-05 11:14:44'),
(2, 'New Ticket comment', 'create', 'Medians\\Help\\Domain\\HelpMessageComment', 'Medians\\Drivers\\Domain\\Driver', '', '', 'New reply at your help message', '\r\n\r\n<table class=\"body-wrap\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: transparent; margin: 0;\">\r\n                                <tbody><tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                    <td style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;\" valign=\"top\"></td>\r\n                                    <td class=\"container\" width=\"600\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;\" valign=\"top\">\r\n                                        <div class=\"content\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; max-width: 600px; display: block; margin: 0 auto; padding: 20px;\">\r\n                                            <table class=\"main\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" itemprop=\"action\" itemscope=\"\" itemtype=\"http://schema.org/ConfirmAction\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; border-radius: 3px; margin: 0; border: none;\">\r\n                                                <tbody><tr style=\"font-family: \'Roboto\', sans-serif; font-size: 14px; margin: 0;\">\r\n                                                    <td class=\"content-wrap\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; color: #495057; font-size: 14px; vertical-align: top; margin: 0;padding: 30px; box-shadow: 0 3px 15px rgba(30,32,37,.06); ;border-radius: 7px; background-color: #fff;\" valign=\"top\">\r\n                                                        <meta itemprop=\"name\" content=\"Confirm Email\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                            <tbody><tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;\" valign=\"top\">\r\n                                                                    <div style=\"margin-bottom: 15px;\">\r\n                                                                        <img src=\"https://trips.medianssolutions.com/uploads/images/logo-6530451a8d927.png\" alt=\"\" height=\"23\">\r\n                                                                    </div>\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                            <tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 20px; line-height: 1.5; font-weight: 500; vertical-align: top; margin: 0; padding: 0 0 10px;\" valign=\"top\">\r\n                                                                    Hey, {{model.receiver.name}}\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                            <tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; color: #878a99; box-sizing: border-box; line-height: 1.5; font-size: 15px; vertical-align: top; margin: 0; padding: 0 0 10px;\" valign=\"top\">\r\n                                                                \r\n                                                                    <p> You have new reply at your help message  </p>\r\n                                                                    <p>{{model.user.name}} sent you reply </p>\r\n                                                                    <p>{{model.comment}} </p>\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                            \r\n\r\n                                                            <tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0; border-top: 1px solid #e9ebec;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0; padding-top: 15px\" valign=\"top\">\r\n                                                                    <div style=\"display: flex; align-items: center;\">\r\n                                                                        <img src=\"https://themesbrand.com/velzon/html/galaxy/assets/images/users/avatar-3.jpg\" alt=\"\" height=\"35\" width=\"35\" style=\"border-radius: 50px;\">\r\n                                                                        <div style=\"margin-left: 8px;\">\r\n                                                                            <span style=\"font-weight: 600;\">{{model.user.name}}</span>\r\n                                                                            <p style=\"font-size: 13px; margin-bottom: 0px; margin-top: 3px; color: #878a99;\">{{model.user.email}}</p>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                        </tbody></table>\r\n                                                    </td>\r\n                                                </tr>\r\n                                            </tbody></table>\r\n                                            <div style=\"text-align: center; margin: 0px auto;\">\r\n                                                <ul style=\"list-style: none;display: flex; justify-content: space-evenly; padding-top: 25px;padding-left: 0px; margin-bottom: 20px; font-family: \'Roboto\', sans-serif;\">\r\n                                                    <li>\r\n                                                        <a href=\"#\" style=\"color: #495057;\">Help Center</a>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <a href=\"#\" style=\"color: #495057;\">Support 24/7</a>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <a href=\"#\" style=\"color: #495057;\">Account</a>\r\n                                                    </li>\r\n                                                </ul>\r\n                                            </div>\r\n                                        </div>\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody></table>', 'Hey, {{model.receiver.name}}\r\nYou have new reply at your help message\r\n', 'on', 4, '2023-11-01 08:27:43', '2023-11-05 11:07:28'),
(3, 'New parent account created', 'create', 'Medians\\Parents\\Domain\\Parents', 'Medians\\Parents\\Domain\\Parents', '', '', 'Your parent account has been created', '\r\n\r\n<table class=\"body-wrap\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: transparent; margin: 0;\">\r\n                                <tbody><tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                    <td style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;\" valign=\"top\"></td>\r\n                                    <td class=\"container\" width=\"600\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;\" valign=\"top\">\r\n                                        <div class=\"content\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; max-width: 600px; display: block; margin: 0 auto; padding: 20px;\">\r\n                                            <table class=\"main\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" itemprop=\"action\" itemscope=\"\" itemtype=\"http://schema.org/ConfirmAction\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; border-radius: 3px; margin: 0; border: none;\">\r\n                                                <tbody><tr style=\"font-family: \'Roboto\', sans-serif; font-size: 14px; margin: 0;\">\r\n                                                    <td class=\"content-wrap\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; color: #495057; font-size: 14px; vertical-align: top; margin: 0;padding: 30px; box-shadow: 0 3px 15px rgba(30,32,37,.06); ;border-radius: 7px; background-color: #fff;\" valign=\"top\">\r\n                                                        <meta itemprop=\"name\" content=\"Confirm Email\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                            <tbody><tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;\" valign=\"top\">\r\n                                                                    <div style=\"margin-bottom: 15px;\">\r\n                                                                        <img src=\"https://trips.medianssolutions.com/uploads/images/logo-6530451a8d927.png\" alt=\"\" height=\"23\">\r\n                                                                    </div>\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                            <tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 20px; line-height: 1.5; font-weight: 500; vertical-align: top; margin: 0; padding: 0 0 10px;\" valign=\"top\">\r\n                                                                    Hey, {{model.receiver.name}}\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                            <tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; color: #878a99; box-sizing: border-box; line-height: 1.5; font-size: 15px; vertical-align: top; margin: 0; padding: 0 0 10px;\" valign=\"top\">\r\n                                                                    <p>Welcome {{model.first_name}}</p>\r\n                                                                    <p>You have new account with name </p> <b>{{model.parent_name}}</b>\r\n                                                                    <p></p>\r\n                                                                    <p>Use your email and this password to login </p>\r\n                                                                    <b>{{model.generated_password}} </b>\r\n                                                                    <br />\r\n                                                                    <p style=\"color:red\"><b>!IMPORTANT: Change your password once you login at the first time.</b></p>\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                            \r\n\r\n                                                            <tr style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0; border-top: 1px solid #e9ebec;\">\r\n                                                                <td class=\"content-block\" style=\"font-family: \'Roboto\', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0; padding-top: 15px\" valign=\"top\">\r\n                                                                    <div style=\"display: flex; align-items: center;\">\r\n                                                                        <img src=\"https://themesbrand.com/velzon/html/galaxy/assets/images/users/avatar-3.jpg\" alt=\"\" height=\"35\" width=\"35\" style=\"border-radius: 50px;\">\r\n                                                                        <div style=\"margin-left: 8px;\">\r\n                                                                            <span style=\"font-weight: 600;\">{{model.user.name}}</span>\r\n                                                                            <p style=\"font-size: 13px; margin-bottom: 0px; margin-top: 3px; color: #878a99;\">{{model.user.email}}</p>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </td>\r\n                                                            </tr>\r\n                                                        </tbody></table>\r\n                                                    </td>\r\n                                                </tr>\r\n                                            </tbody></table>\r\n                                            <div style=\"text-align: center; margin: 0px auto;\">\r\n                                                <ul style=\"list-style: none;display: flex; justify-content: space-evenly; padding-top: 25px;padding-left: 0px; margin-bottom: 20px; font-family: \'Roboto\', sans-serif;\">\r\n                                                    <li>\r\n                                                        <a href=\"#\" style=\"color: #495057;\">Help Center</a>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <a href=\"#\" style=\"color: #495057;\">Support 24/7</a>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <a href=\"#\" style=\"color: #495057;\">Account</a>\r\n                                                    </li>\r\n                                                </ul>\r\n                                            </div>\r\n                                        </div>\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody></table>', '                                                                    Welcome {{model.first_name}}\r\n                                                                    You have new account with name  {{model.parent_name}}\r\n                                  ', 'on', 4, '2023-11-04 06:10:17', '2023-11-08 13:35:30'),
(4, 'Pickup Location updated', 'update', 'Medians\\Locations\\Domain\\PickupLocation', 'Medians\\Drivers\\Domain\\Driver', '', '', 'Good morning {{receiver.first_name}}, Your route has new update', '{{receiver.name}}\r\nYou route have an update at your pickup locations\r\nPlease follow the route at the map.', '{{receiver.name}}\r\nYou route have an update at your pickup locations\r\nPlease follow the route at the map.', 'on', 4, '2023-11-05 10:35:52', '2023-11-06 23:56:53'),
(5, 'Driver info updated', 'update', 'Medians\\Drivers\\Domain\\Driver', 'Medians\\Drivers\\Domain\\Driver', '', '', 'Hello {{receiver.first_name}}, Your Profile updated ', 'hey {{receiver.name}}\r\nYou information has been updated.\r\nPlease contact us if your updated information is incorrect', 'hey {{receiver.name}}\r\nYou information has been updated.\r\nPlease contact us if your updated information is incorrect', 'on', 4, '2023-11-05 11:10:54', '2023-11-06 05:41:42'),
(6, 'New Pickup Location', 'create', 'Medians\\Locations\\Domain\\PickupLocation', 'Medians\\Drivers\\Domain\\Driver', '', '', 'Your route has new pickup location', 'Hello {{receiver.name}}\r\nYour route have new pickup location, please follow your route through the Map.\r\n', 'Hello {{receiver.name}}\r\nYour route have new pickup location, please follow your route through the Map.\r\n', 'on', 4, '2023-11-06 23:04:59', '2023-11-06 23:04:59'),
(7, 'Pickup update alert for parent', 'update', 'Medians\\Locations\\Domain\\PickupLocation', 'Medians\\Parents\\Domain\\Parents', '', '', 'You child location has been updated', 'You child location has been updated', 'You child location has been updated', 'on', 4, '2023-11-23 17:41:51', '2023-11-23 17:41:51'),
(8, 'Trip started ', 'create', 'Medians\\Trips\\Domain\\TripPickup', 'Medians\\Parents\\Domain\\Parents', '', '', 'New Trip started ', 'Good morning {{receiver.first_name}},\r\nTrip of today has been started ', 'Good morning {{receiver.first_name}},\r\nTrip of today has been started ', 'on', 4, '2023-11-23 23:25:23', '2023-11-24 00:03:19');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `parent_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `generated_password` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `status` varchar(5) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `model` varchar(255) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `access` int(11) DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`role_id`, `model`, `action`, `access`, `created_at`, `updated_at`) VALUES
(3, 'Dashboard', 'Dashboard.index', 1, '2023-11-03 01:14:01', '2023-11-17 22:10:29'),
( 3, 'Trips', 'Trips.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 3, 'Drivers', 'Drivers.index', 1, '2023-11-03 01:14:01', '2023-11-17 05:21:10'),
( 3, 'Vehicles', 'Vehicles.index', 1, '2023-11-03 01:14:01', '2023-11-17 05:21:10'),
( 3, 'HelpMessage', 'HelpMessage.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 3, 'User', 'User.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 3, 'Notification', 'Notification.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'NotificationEvent', 'NotificationEvent.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'SystemSettings', 'SystemSettings.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 3, 'PickupLocations', 'PickupLocations.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 3, 'Routes', 'Routes.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 3, 'Students', 'Students.index', 1, '2023-11-03 01:14:01', '2023-11-17 05:21:02'),
( 3, 'Parents', 'Parents.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'Dashboard', 'Dashboard.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'Trips', 'Trips.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'Drivers', 'Drivers.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'Vehicles', 'Vehicles.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'HelpMessage', 'HelpMessage.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'User', 'User.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'Notification', 'Notification.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'PickupLocations', 'PickupLocations.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'Routes', 'Routes.index', 1, '2023-11-03 01:14:01', '2023-11-17 05:20:37'),
( 1, 'Students', 'Students.index', 1, '2023-11-03 01:14:01', '2023-11-17 05:20:37'),
( 1, 'Parents', 'Parents.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:42'),
( 1, 'Event', 'Event.index', 1, '2023-11-03 01:14:01', '2023-11-16 19:29:59'),
( 1, 'Destination', 'Destinations.index', 1, '2023-11-03 01:14:01', '2023-11-23 13:01:40'),
( 3, 'Destination', 'Destinations.index', 1, '2023-11-03 01:14:01', '2023-11-23 13:01:43');

-- --------------------------------------------------------

--
-- Table structure for table `pickup_locations`
--

CREATE TABLE `pickup_locations` (
  `pickup_id` int(11) NOT NULL,
  `model_type` varchar(255) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `location_name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `saturday` tinyint(1) DEFAULT NULL,
  `sunday` int(11) DEFAULT NULL,
  `monday` int(11) DEFAULT NULL,
  `tuesday` int(11) DEFAULT NULL,
  `wednesday` int(11) DEFAULT NULL,
  `thursday` int(11) DEFAULT NULL,
  `friday` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'Super Administrator'),
(3, 'Moderators');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `route_id` int(11) NOT NULL,
  `route_name` varchar(255) NOT NULL,
  `description` text,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  `model` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `current_school` varchar(255) DEFAULT NULL,
  `grade_level` int(11) DEFAULT NULL,
  `transfer_status` enum('Pending','Approved','Completed') DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `code`, `value`, `created_by`, `created_at`, `updated_at`) VALUES
(9, 'welcome_message_subject', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(10, 'welcome_message_icon', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(11, 'notifications_welcome_message', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(12, 'smtp_sender', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(13, 'smtp_user', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(14, 'smtp_password', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(15, 'smtp_host', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(16, 'smtp_port', '', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(17, 'smtp_auth', '1', 1, '2023-10-31 03:38:27', '2023-10-31 03:38:27'),
(19, 'sitename', 'Medians trips', 4, '2023-11-01 07:14:17', '2023-11-01 07:14:17'),
(20, 'lang', 'english', 4, '2023-11-01 07:14:17', '2023-11-01 07:14:17');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `trip_id` int(11) NOT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `trip_date` date DEFAULT NULL,
  `trip_status` enum('Scheduled','In Progress','Completed') DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `trip_destinations`
--

CREATE TABLE `trip_destinations` (
  `trip_destination_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` int(11) NOT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `status` enum('waiting','done','') DEFAULT NULL,
  `dropoff_time` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `trip_pickups`
--

CREATE TABLE `trip_pickups` (
  `trip_pickup_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` int(11) NOT NULL,
  `pickup_id` int(11) DEFAULT NULL,
  `status` enum('','waiting','moving','done','') DEFAULT NULL,
  `boarding_time` datetime DEFAULT NULL,
  `dropoff_time` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `trip_track`
--

CREATE TABLE `trip_track` (
  `trip_track_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vacations`
--

CREATE TABLE `vacations` (
  `vacation_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `vehicle_id` int(11) NOT NULL,
  `vehicle_name` varchar(255) NOT NULL,
  `vehicle_type` varchar(255) DEFAULT NULL,
  `plate_number` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `maintenance_status` varchar(100) DEFAULT 'active',
  `driver_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `last_latitude` varchar(20) DEFAULT NULL,
  `last_longitude` varchar(20) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `custom_fields`
--
ALTER TABLE `custom_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `itemid` (`model_id`),
  ADD KEY `fieldid` (`field_id`),
  ADD KEY `value` (`value`),
  ADD KEY `class` (`model_type`);

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`destination_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`driver_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `help_messages`
--
ALTER TABLE `help_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `help_message_comments`
--
ALTER TABLE `help_message_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications_events`
--
ALTER TABLE `notifications_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`parent_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indexes for table `pickup_locations`
--
ALTER TABLE `pickup_locations`
  ADD PRIMARY KEY (`pickup_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`route_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);


--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`trip_id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indexes for table `trip_destinations`
--
ALTER TABLE `trip_destinations`
  ADD PRIMARY KEY (`trip_destination_id`);

--
-- Indexes for table `trip_pickups`
--
ALTER TABLE `trip_pickups`
  ADD PRIMARY KEY (`trip_pickup_id`);

--
-- Indexes for table `trip_track`
--
ALTER TABLE `trip_track`
  ADD PRIMARY KEY (`trip_track_id`) USING BTREE,
  ADD UNIQUE KEY `trip_track_id_2` (`trip_track_id`),
  ADD KEY `trip_id` (`trip_id`),
  ADD KEY `trip_track_id` (`trip_track_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `firstname` (`first_name`),
  ADD KEY `lastname` (`last_name`);

--
-- Indexes for table `vacations`
--
ALTER TABLE `vacations`
  ADD PRIMARY KEY (`vacation_id`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`vehicle_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `custom_fields`
--
ALTER TABLE `custom_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `destination_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `driver_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `help_messages`
--
ALTER TABLE `help_messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `help_message_comments`
--
ALTER TABLE `help_message_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications_events`
--
ALTER TABLE `notifications_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `parent_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `pickup_locations`
--
ALTER TABLE `pickup_locations`
  MODIFY `pickup_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `route_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `trip_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip_destinations`
--
ALTER TABLE `trip_destinations`
  MODIFY `trip_destination_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip_pickups`
--
ALTER TABLE `trip_pickups`
  MODIFY `trip_pickup_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vacations`
--
ALTER TABLE `vacations`
  MODIFY `vacation_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `vehicle_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `trips`
--
ALTER TABLE `trips`
  ADD CONSTRAINT `trips_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`driver_id`);
